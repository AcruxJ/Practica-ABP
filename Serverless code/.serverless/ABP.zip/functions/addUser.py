import json
import boto3


def lambda_handler(event, context):
    ddb = boto3.resource('dynamodb')
    table = ddb.Table('UserTable')

    body = json.loads(event["body"])
    
    item = {
        "photoID": body["user"],
        "email": body["email"],
        "created_at": str(datetime.now()),
        "photo": body["nameS3"],
    }
    table.put_item(Item=item)

    return {
        "statusCode": 200,
        "body": json.dumps(item)
    }